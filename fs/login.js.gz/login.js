var save_command = false;
check_ap_mode();
var timeout_global = 5000; //default is 5secs
load_conf_login();
login_session_check();
var spinner_load= '<div id="circularG" style="margin-top:-5px"><div id="circularG_1" class="circularG"></div>';
spinner_load += '<div id="circularG_2" class="circularG"></div>';
spinner_load += '<div id="circularG_3" class="circularG"></div><div id="circularG_4" class="circularG"></div><div id="circularG_5" class="circularG"></div>';
spinner_load += '<div id="circularG_6" class="circularG"></div><div id="circularG_7" class="circularG"></div><div id="circularG_8" class="circularG"></div></div>';
function off_overlay_login(){
  document.getElementById("overlay_login").style.display = "none";
  document.getElementById("main_div").style.filter = "none";
}
function on_overlay_login() {
  document.getElementById("overlay_login").style.display = "block";
  document.getElementById("main_div").style.filter = "blur(2px)";
  document.getElementById("overlay_login").style.filter = "none";
  document.getElementById("login_warning").innerHTML ="";
  document.getElementById("login_password").value = "";
  document.getElementById("login_password").focus();
}
function change_pass_info(){
	var a = document.getElementById("old_password").value;
	var b = document.getElementById("new_pass1").value;
	var c = document.getElementById("new_pass2").value;
	var x = document.getElementById("change_pass_warning");
	if(b != c){
		x.innerHTML = "New Passwords are not same!";
		return;
	}
	x.innerHTML = spinner_load;
	xhr_send("change_pass", JSON.stringify({old_pass:a, new_pass:b}), function(i){
		if(i.status == "success"){
			var data = i.data;
			if(data.status = "unauthorized"){
				x.innerHTML = "passwords don’t match, incorrect password!";
			}else if(data.status = "confirm"){
				x.innerHTML = "Successfully changes password";
			}
		}else{
			x.innerHTML = i.status;
		}
	});
}
function xhr_send(rpc, comm, callback){
	var xhr = new XMLHttpRequest();
	xhr.open("POST", "/rpc/"+rpc, true);
	xhr.setRequestHeader('Content-Type', 'application/json');
	xhr.send(comm);
	xhr.timeout = timeout_global;
	xhr.ontimeout = function (e) {
		callback({status:"No response from controller!"});
	};
	xhr.onreadystatechange = function() {
		if(xhr.readyState != 4){return;}
		if(xhr.status == 200){
			callback({status:"success", "data": JSON.parse(xhr.responseText)});
		}else{
			callback({status:"Request Failed!"});
		}
	}
}
function validate_cookie(callback){
	var ver_key = getCookie();
	ver_key = (ver_key == "") ? "0" : ver_key;
	xhr_send("validate_key", JSON.stringify({key:ver_key}), function(i){
		if(i.status == "success" && i.data.status == "confirm"){
			callback(true);
		}else{
			setCookie("");
			login_session_check();
			callback(false);
		}
	});
}
function on_overlay_change_pass(){
	document.getElementById("overlay_change_pass").style.display = "block";
	document.getElementById("main_div").style.filter = "blur(2px)";
	document.getElementById("overlay_change_pass").style.filter = "none";
}
function off_overlay_change_pass(){
  document.getElementById("overlay_change_pass").style.display = "none";
  document.getElementById("main_div").style.filter = "none";
}
function setCookie(cvalue) {	
  document.cookie = "verification=" + String(cvalue);
}
function change_password(){
var logged = check_password();
if(!logged){
on_overlay_change_pass();
}else{
document.getElementById("login_warning").innerHTML = "Please log out first to change password!";	
}
}
var pass_field = document.getElementById("login_password");
pass_field.addEventListener("keyup", function (event){
	if(event.keyCode == 13){
		event.preventDefault();
		confirm_password();	
	}
});
function confirm_password(){
	var x = document.getElementById("login_warning");
	var pass_local = document.getElementById("login_password").value;
	var logged = check_password();
	if(logged){	x.innerHTML = "Logged in already!";	return;}
	x.innerHTML = spinner_load;
	xhr_send("login", JSON.stringify({pass:pass_local}),  function(i){
	if(i.data.status == "authorized"){
		x.innerHTML = "Login successful!";
		setCookie(i.data.key);
		login_session_check();
		off_overlay_login();
		if(save_command){
			save_conf();
		}
	}else if(i.data.status == "unauthorized"){
		x.innerHTML = "passwords don’t match, incorrect password!";
		return;
	}else{
		x.innerHTML = i.status;
	}
	});
}
function login_confirm(input){
	if(input.innerHTML == "Login"){
	on_overlay_login();	
	}else if(input.innerHTML == "Logout"){
	setCookie("");
	login_session_check();
	}
}
function getCookie() {
	let name = "verification=";
	let ca = document.cookie.split(';');
	for(let i = 0; i < ca.length; i++) {
		let c = ca[i];
		while (c.charAt(0) == ' ') {
			c = c.substring(1);
		}
		if (c.indexOf(name) == 0) {
			return c.substring(name.length, c.length);
		}
	}
  return "";
}
function check_password(){
	var ver_key = getCookie();
	if(ver_key != ""){
		return true;
	}else{
		return false;
	}
}
function login_session_check(){
var logged = check_password();
document.getElementById("log_info").innerHTML = (logged)? "Logged In" : "Logged Out";
document.getElementById("log_button").innerHTML = (logged) ? "Logout" : "Login";	
}
function load_conf_login(){
var xhr = new XMLHttpRequest();
xhr.open("POST", "/rpc/FS.Get", true);
xhr.setRequestHeader('Content-Type', 'application/json');
var comm = {"filename": "setting.json"};
xhr.send(JSON.stringify(comm));
xhr.onload = function() {
var data = JSON.parse(this.responseText);
var old_json = JSON.parse(window.atob(data.data));
changetheme(old_json.theme);
timeout_global = old_json.webserver.timeout;
}
}
function changetheme(input){
var sheets = document.getElementsByTagName('link');
if(input == 1){
sheets[0].href = "light.css";
}else{
sheets[0].href = "dark.css";
}
}

var login_ap = setInterval(check_ap_mode, 5000);

function check_ap_mode(){
xhr_send("check_ap_mode", null, function(i){
	if(i.status == "success"){
		var a = i.data.mode;
		var b = i.data.uptime;
		if(a == true && b < 300){
			document.getElementById("log_button").className = "disabled";
			setCookie("0");
		}else{
			document.getElementById("log_button").classList.remove("disabled");
			if(getCookie() == "0"){setCookie("");}
			clearInterval(login_ap);
		}
		login_session_check();
	}
});	
}